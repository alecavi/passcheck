#include <iostream>
#include <string>

void authenticated(std::string u); 
void rejected(std::string u);
